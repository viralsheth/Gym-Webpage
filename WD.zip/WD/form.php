<?php
$insert = false;
if(isset($_POST['name'])){
    // Set connection variables
    $server = "localhost";
    $username = "root";
    $password = "";

    // Create a database connection
    $con = mysqli_connect($server, $username, $password);

    // Check for connection success
    if(!$con){
        die("connection to this database failed due to" . mysqli_connect_error());
    }
    // echo "Success connecting to the db";

    // Collect post variables
    $name = $_POST['name'];
    $age = $_POST['age'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $message = $_POST['message'];
    $sql = "INSERT INTO `contactus`.`contact` (`name`, `age`, `phone`, `email`, `message`) VALUES ('$name', '$age', '$phone', '$email', '$message');";
    // echo $sql;

    // Execute the query
    if($con->query($sql) == true){
        // echo "Successfully inserted";

        // Flag for successful insertion
        $insert = true;
    }
    else{
        echo "ERROR: $sql <br> $con->error";
    }

    // Close the database connection
    $con->close();
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Contact Us | LEANFIT</title>
  <link rel="stylesheet" href="style.css">
  <script src="validate.js"></script>
  <style>
    #backg{
      width: 100%;
      position: absolute;
      z-index: -1;
      opacity: 0.80;
    }
  </style>
</head>
<body>
  <img id="backg" src="formbg.jpg">
  <header>
    <nav>
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="classes.html">Classes</a></li>
        <li><a href="schedule.html">Schedule</a></li>
        <li><a href="contact.html">Contact Us</a></li>
      </ul>
    </nav>
  </header>

  <section id="contact">
    <div class="container">
      <h2>Contact Us</h2>
      <form action="form.php" method="post">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" placeholder="Your Name" required>

        <label for="age">Age</label>
        <input type="number" id="age" name="age" placeholder="Your Age" required>

        <label for="phone">Phone Number</label>
        <input type="tel" id="phone" name="phone" placeholder="Your Mobile no." required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="Your Email" required>

        <label for="message">Message</label>
        <textarea id="message" name="message" placeholder="Your Message" required></textarea>

        <button class="btn">Submit</button>
      </form>
      <?php
        if($insert == true){
        echo "<p class='submitMsg'>Thanks for submitting your form.</p>";
        }
      ?>
    </div>
  </section>

  <footer>
    <p>&copy; 2023 LEANFIT. All rights reserved.</p>
  </footer>
  
</body>
</html>
